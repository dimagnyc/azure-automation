# Enable-MFA.ps1
# Sample PowerShell script to enable MFA for all users in Azure AD

Connect-MsolService

$users = Get-MsolUser -All | Where-Object { $_.StrongAuthenticationRequirements.Count -eq 0 }

foreach ($user in $users) {
    $mfaSettings = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationRequirement
    $mfaSettings.RelyingParty = "*"
    $mfaSettings.State = "Enabled"
    Set-MsolUser -UserPrincipalName $user.UserPrincipalName -StrongAuthenticationRequirements @($mfaSettings)
}
