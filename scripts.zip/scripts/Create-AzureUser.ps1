# Create-AzureUser.ps1
# Sample PowerShell script to create a user in Azure AD

param (
    [string]$UserPrincipalName,
    [string]$DisplayName,
    [string]$Password
)

Connect-AzureAD

New-AzureADUser -DisplayName $DisplayName `
                -PasswordProfile @{ForceChangePasswordNextLogin=$true; Password=$Password} `
                -UserPrincipalName $UserPrincipalName `
                -AccountEnabled $true `
                -MailNickName $UserPrincipalName.Split('@')[0]
