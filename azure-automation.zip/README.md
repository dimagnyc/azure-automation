# ☁️ Azure Automation Scripts

This repository contains sample PowerShell and Bash scripts used for automating Azure administrative tasks.

## Sample Scripts

- User provisioning
- Enabling MFA
- Resource group clean-up
- Azure VM backup routines
- Tagging policies

> Ideal for building repeatable and secure workflows.
